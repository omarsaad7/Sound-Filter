function[fk,x]=fft_signals_project(Fs,y)
M=0;%padding
ts=1/Fs;
N=length(y);
x=ts*fft(y,N+M);%changing to freqdomain
x=abs(fftshift(x));%shifting the signal in freqdomain
n=0:N-1;
fk=n*Fs/(N+M);%freq
fk=fk-(0.5*Fs);
end